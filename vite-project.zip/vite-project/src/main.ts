import "./style.css";

const form = document.querySelector<HTMLFormElement>(".contact_form");
const contactList = document.querySelector<HTMLUListElement>(".contact_list");
const name = document.querySelector<HTMLInputElement>("#name");
const surname = document.querySelector<HTMLInputElement>("#surname");
const phone = document.querySelector<HTMLInputElement>("#phone");
const email = document.querySelector<HTMLInputElement>("#email");
const addOrChangeBtn =
  document.querySelector<HTMLButtonElement>(".addOrChange_btn");

let arrList: any[] = [];

form?.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!name || !surname || !phone || !email) return;

  const user = {
    name: name.value,
    surname: surname.value,
    phone: phone.value,
    email: email.value,
  };

  const userKey = `user_${name.value}_${surname.value}_${phone.value}_${email.value}`;
  localStorage.setItem(userKey, JSON.stringify(user));

  const item = document.createElement("li");
  const contact = document.createElement("div");
  const nameItem = document.createElement("p");
  const surnameItem = document.createElement("p");
  const phoneItem = document.createElement("p");
  const emailItem = document.createElement("p");
  const deleteBtn = document.createElement("button");
  const changeBtn = document.createElement("button");

  nameItem.textContent = name.value;
  surnameItem.textContent = surname.value;
  phoneItem.textContent = phone.value;
  emailItem.textContent = email.value;

  deleteBtn.textContent = "sil";
  changeBtn.textContent = "düzəliş";
  deleteBtn.classList.add("addOrChange_btn");
  changeBtn.classList.add("addOrChange_btn");

  contact.appendChild(nameItem);
  contact.appendChild(surnameItem);
  contact.appendChild(phoneItem);
  contact.appendChild(emailItem);
  contact.appendChild(deleteBtn);
  contact.appendChild(changeBtn);
  contact.classList.add("contact_style");

  item.appendChild(contact);
  contactList?.appendChild(item);
  arrList.push(item);
  // Delete functionality
  deleteBtn.addEventListener("click", () => {
    localStorage.removeItem(userKey);
    contactList?.removeChild(item);
    arrList.splice(arrList.indexOf(item), 1);
  });
  name.value = "";
  surname.value = "";
  phone.value = "";
  email.value = "";
  // Change functionality
  changeBtn.addEventListener("click", () => {
    if (addOrChangeBtn) {
      addOrChangeBtn.textContent = "Düzəliş Et";
    }
    name.value = user.name;
    surname.value = user.surname;
    phone.value = user.phone;
    email.value = user.email;

    localStorage.removeItem(userKey);
    contactList?.removeChild(item);
    arrList.splice(arrList.indexOf(item), 1);
  });
  if (addOrChangeBtn) {
    addOrChangeBtn.textContent = "Əlavə Et";
  }
});
const filterForm = document.querySelector<HTMLFormElement>(".filter_form");

filterForm?.addEventListener("submit", (event) => {
  event.preventDefault();

  const filterParam =
    document.querySelector<HTMLSelectElement>("#filter__param");
  const filterText = document.querySelector<HTMLInputElement>("#filter__text");

  if (!filterParam || !filterText) return;

  const paramValue = filterParam.value.toLowerCase();
  const searchText = filterText.value.toLowerCase();
  const listItems = document.querySelectorAll<HTMLLIElement>(".contact_style");
  if (searchText !== "") {
    listItems.forEach((item) => {
      const itemText = item.textContent?.toLowerCase();
      console.log(item.textContent);
      if (itemText?.includes(searchText) || searchText === "") {
        item.style.display = "inner";
        if (paramValue == "ad") {
          if (itemText?.includes(searchText)) {
            item.style.display = "inner";
          } else {
            item.style.display = "none";
          }
        } else if (paramValue == "soyad") {
          if (itemText?.includes(searchText)) {
            item.style.display = "inner";
          } else {
            item.style.display = "none";
          }
        } else if (paramValue == "nömrə") {
          if (itemText?.includes(searchText)) {
            item.style.display = "inner";
          } else {
            item.style.display = "none";
          }
        } else if (paramValue == "e-poçt") {
          if (itemText?.includes(searchText)) {
            item.style.display = "inner";
          } else {
            item.style.display = "none";
          }
        }
      } else {
        item.style.display = "none";
      }
    });
  }
});
